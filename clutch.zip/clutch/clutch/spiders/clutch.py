from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import ClutchItem

#from datetime import date


class ClutchSpider(CrawlSpider):

    name = "clutch"

    start_urls = [
                "https://clutch.co/agencies"
    ]

    # rules = (
    #     Rule(LinkExtractor(restrict_css=([".pagination li:last-child a"]))),
    #     Rule(LinkExtractor(restrict_css=("div.info h4 a")),callback="clutch"),  
    # )


    def parse(self, response):

        

        for data in response.css(".provider-row"):

            companies = ClutchItem()

            companies["name"] = data.css(".company-name a::text").extract_first()

            companies["location"] = data.css(".location-city span::text").extract()
            companies["location"] = " ".join(companies["location"])

            companies["website"] = data.css(".website-link.website-link-a a::attr(href)").extract_first()

            companies["minimum_project_size"] = data.css(".module-list div:nth-child(1)::text").extract_first()

            if companies["minimum_project_size"]:
                companies["minimum_project_size"] = companies["minimum_project_size"].strip()


            companies["employee_range"] = data.css(".module-list div:nth-child(2)::text").extract_first()

            if companies["employee_range"]:
                companies["employee_range"] = companies["employee_range"].strip()

            companies["avg_hourly_rate"] = data.css(".module-list div:nth-child(3)::text").extract_first()

            yield companies


        next_page = response.css("li.next a::attr(href)").extract_first()


        yield response.follow(next_page, callback= self.parse)

        
 